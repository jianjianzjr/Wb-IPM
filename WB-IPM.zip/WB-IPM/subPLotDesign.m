
figure,
subplot('Position',[0.0617,0.6235,0.3148,0.3148]),
subplot('Position',[0.0617 0.5432,0.3148,0.0679]),
subplot('Position',[0.3889,0.6235,0.0679,0.3148]),

subplot('Position',[0.5185,0.6235,0.3148,0.3148]),
subplot('Position',[0.5185 0.5432,0.3148,0.0679]),
subplot('Position',[137/162,0.6235,0.0679,0.3148]),

subplot('Position',[0.0617,0.1420,0.3148,0.3148]),
subplot('Position',[0.0617 0.0617,0.3148,0.0679]),
subplot('Position',[0.3889,0.1420,0.0679,0.3148]),

subplot('Position',[0.5185,0.1420,0.3148,0.3148]),
subplot('Position',[0.5185 0.0617,0.3148,0.0679]),
subplot('Position',[137/162,0.1420,0.0679,0.3148]),
