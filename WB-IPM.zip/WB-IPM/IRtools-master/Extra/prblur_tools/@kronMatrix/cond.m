function x = cond(k)

x = cond(k.a) * cond(k.b);


