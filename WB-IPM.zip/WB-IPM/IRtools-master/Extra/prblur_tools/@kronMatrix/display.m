function display(k)
%  kronMatrix display(k)
%
%     prints the elements of k.a and k.b
%

disp (sprintf ('a ='));
disp(k.a);
disp (sprintf ('b ='));
disp(k.b);
